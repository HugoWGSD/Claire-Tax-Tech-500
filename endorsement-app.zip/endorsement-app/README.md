# Deploying the Endorsement Helper

A ~10-minute guide to going live with Vercel's free tier.

## What you have

```
endorsement-app/
├── index.html       ← the tool itself
└── api/
    └── generate.js  ← serverless proxy that calls Anthropic
```

The browser hits your domain → loads `index.html` → user fills out form → JS posts to `/api/generate.js` → that function (running on Vercel's server, where your API key lives privately) calls Anthropic → result comes back to the browser.

---

## Step 1 — Get an Anthropic API key

1. Go to [console.anthropic.com](https://console.anthropic.com)
2. Sign in (or create an account)
3. Under **Settings → API Keys**, click **Create Key**
4. Name it something like "endorsement-helper" and copy the key — you'll paste it in step 4
5. Under **Settings → Billing**, add a payment method and **set a monthly spend limit** (e.g. $20). This is your safety net against runaway usage.

**Cost estimate:** with Haiku 4.5, each endorsement generation costs roughly $0.001–0.003. 500 endorsements ≈ $1.50. The spend limit is your insurance policy.

---

## Step 2 — Create a Vercel account

1. Go to [vercel.com/signup](https://vercel.com/signup)
2. Sign up with GitHub, GitLab, or email — GitHub is easiest

---

## Step 3 — Deploy the folder

**Easiest path (no command line):**

1. Zip the `endorsement-app` folder
2. On vercel.com, click **Add New → Project**
3. Drag the folder (or the zip) into the upload area
4. Vercel auto-detects it as a static site with a serverless function. Click **Deploy**

**Alternative (CLI, if you prefer):**

```bash
npm install -g vercel
cd endorsement-app
vercel
# Answer the prompts (link to your account, project name, etc.)
```

Either way, you'll get a URL like `https://endorsement-app-abc123.vercel.app`. The site loads but the generate button won't work yet — one more step.

---

## Step 4 — Add your API key as an environment variable

1. In Vercel, open your project → **Settings → Environment Variables**
2. Add a new variable:
   - **Name:** `ANTHROPIC_API_KEY`
   - **Value:** the key you copied from Anthropic in step 1
   - **Environments:** check Production, Preview, and Development
3. Click **Save**
4. Go back to the **Deployments** tab → click the latest deployment → click the **⋯ menu → Redeploy** so the new env var takes effect

Now the generate button should work. Test it end-to-end before sharing.

---

## Step 5 (optional but recommended) — Lock it down to your domain

By default, anyone could find your proxy URL and use your API credits to generate text for themselves. To prevent that:

1. In Vercel **Settings → Environment Variables**, add another variable:
   - **Name:** `ALLOWED_ORIGINS`
   - **Value:** your Vercel URL, e.g. `https://endorsement-app-abc123.vercel.app`
   - If you later add a custom domain (e.g. `endorse.kipsi.com`), add it too, comma-separated: `https://endorsement-app-abc123.vercel.app,https://endorse.kipsi.com`
2. Redeploy

Now only requests coming from your own page can hit the proxy.

---

## Step 6 (optional) — Custom domain

Vercel domains look like `endorsement-app-abc123.vercel.app`. If you'd rather use something like `endorse.kipsi.com`:

1. Project → **Settings → Domains** → add your domain
2. Vercel gives you a CNAME or A record to set at your DNS provider
3. Once it propagates, update `ALLOWED_ORIGINS` to include the new domain

---

## Sharing the link

Once it's live, just send the URL anywhere — LinkedIn DMs, email blasts to customers/investors, a Slack message to past colleagues. No login required, no Claude account needed on their end. They fill out the form, get their endorsement, click through to the voting page, paste, submit.

---

## Monitoring

- **Anthropic console** → Usage tab shows real-time spend
- **Vercel dashboard** → Functions tab shows how many calls have come in
- If something breaks, **Logs** in Vercel will show the error

---

## If you want to swap the model

In `api/generate.js`, change the `model` field:
- `claude-haiku-4-5-20251001` — fastest, cheapest, fine for this use case (current default)
- `claude-sonnet-4-5-20250929` — higher quality, ~10x more expensive
- `claude-opus-4-7` — top quality, expensive, overkill for short endorsements
